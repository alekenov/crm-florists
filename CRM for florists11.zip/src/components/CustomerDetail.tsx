import { useState } from "react";
import { ArrowLeft, Phone, Calendar, TrendingUp, Plus, Edit3, Check, X, User, ShoppingBag, Receipt, Clock } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";

interface Customer {
  id: number;
  name?: string;
  phone: string;
  memberSince: Date;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate: Date;
  status: 'active' | 'vip' | 'inactive';
  notes?: string;
}

interface Order {
  id: string;
  number: string;
  date: Date;
  total: number;
  status: 'pending' | 'confirmed' | 'in_progress' | 'ready' | 'delivered' | 'cancelled';
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
}

interface CustomerDetailProps {
  customerId: number;
  customers: Customer[];
  onClose: () => void;
  onUpdateCustomer: (customer: Customer) => void;
  onViewOrder?: (orderId: string) => void;
}

// Мок-данные заказов для примера
const mockOrders: Order[] = [
  // Заказы для первого клиента (Анны Кожемякиной)
  {
    id: '1',
    number: '40421',
    date: new Date(2024, 8, 2),
    total: 25000,
    status: 'delivered',
    items: [
      { name: 'Букет роз "Страсть"', quantity: 1, price: 18000 },
      { name: 'Упаковка премиум', quantity: 1, price: 3000 },
      { name: 'Открытка', quantity: 1, price: 500 }
    ]
  },
  {
    id: '2',
    number: '40412',
    date: new Date(2024, 7, 25),
    total: 15000,
    status: 'delivered',
    items: [
      { name: 'Букет роз красных', quantity: 25, price: 600 }
    ]
  },
  {
    id: '3',
    number: '40401',
    date: new Date(2024, 7, 18),
    total: 8500,
    status: 'delivered',
    items: [
      { name: 'Букет тюльпанов', quantity: 1, price: 8500 }
    ]
  },
  {
    id: '4',
    number: '40395',
    date: new Date(2024, 6, 10),
    total: 32000,
    status: 'delivered',
    items: [
      { name: 'Свадебный букет невесты', quantity: 1, price: 22000 },
      { name: 'Бутоньерка жениха', quantity: 1, price: 3500 },
      { name: 'Декор стола', quantity: 3, price: 2167 }
    ]
  },
  {
    id: '5',
    number: '40387',
    date: new Date(2024, 5, 20),
    total: 12000,
    status: 'cancelled',
    items: [
      { name: 'Композиция на День рождения', quantity: 1, price: 12000 }
    ]
  },
  
  // Заказы для второго клиента
  {
    id: '6',
    number: '40418',
    date: new Date(2024, 8, 1),
    total: 9500,
    status: 'delivered',
    items: [
      { name: 'Букет хризантем', quantity: 1, price: 7500 },
      { name: 'Доставка', quantity: 1, price: 2000 }
    ]
  },
  {
    id: '7',
    number: '40407',
    date: new Date(2024, 7, 15),
    total: 6800,
    status: 'delivered',
    items: [
      { name: 'Букет гербер', quantity: 1, price: 6800 }
    ]
  },
  {
    id: '8',
    number: '40392',
    date: new Date(2024, 6, 8),
    total: 14500,
    status: 'delivered',
    items: [
      { name: 'Корзина цветов', quantity: 1, price: 14500 }
    ]
  },

  // Заказы для третьего клиента
  {
    id: '9',
    number: '40415',
    date: new Date(2024, 7, 28),
    total: 18900,
    status: 'delivered',
    items: [
      { name: 'Букет пионов', quantity: 1, price: 16000 },
      { name: 'Ваза', quantity: 1, price: 2900 }
    ]
  },
  {
    id: '10',
    number: '40403',
    date: new Date(2024, 6, 22),
    total: 11200,
    status: 'delivered',
    items: [
      { name: 'Букет лилий', quantity: 1, price: 11200 }
    ]
  },

  // Заказы для четвертого клиента
  {
    id: '11',
    number: '40420',
    date: new Date(2024, 8, 3),
    total: 7300,
    status: 'ready',
    items: [
      { name: 'Букет ромашек', quantity: 1, price: 5500 },
      { name: 'Упаковка', quantity: 1, price: 800 },
      { name: 'Лента', quantity: 1, price: 1000 }
    ]
  },
  {
    id: '12',
    number: '40408',
    date: new Date(2024, 7, 12),
    total: 13700,
    status: 'delivered',
    items: [
      { name: 'Букет орхидей', quantity: 1, price: 13700 }
    ]
  },

  // Заказы для пятого клиента
  {
    id: '13',
    number: '40419',
    date: new Date(2024, 8, 4),
    total: 22100,
    status: 'in_progress',
    items: [
      { name: 'Композиция "Элегант"', quantity: 1, price: 19500 },
      { name: 'Подставка', quantity: 1, price: 2600 }
    ]
  },
  {
    id: '14',
    number: '40410',
    date: new Date(2024, 7, 20),
    total: 8900,
    status: 'delivered',
    items: [
      { name: 'Букет альстромерий', quantity: 1, price: 8900 }
    ]
  }
];

function formatDate(date: Date): string {
  const now = new Date();
  const diffInMonths = (now.getFullYear() - date.getFullYear()) * 12 + now.getMonth() - date.getMonth();
  
  if (diffInMonths === 0) {
    return 'Этот месяц';
  } else if (diffInMonths === 1) {
    return '1 месяц назад';
  } else if (diffInMonths < 12) {
    return `${diffInMonths} мес. назад`;
  } else {
    const years = Math.floor(diffInMonths / 12);
    return `${years} ${years === 1 ? 'год' : 'года'} назад`;
  }
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('ru-KZ', {
    style: 'currency',
    currency: 'KZT',
    minimumFractionDigits: 0
  }).format(amount).replace('KZT', '₸');
}

function formatOrderDate(date: Date): string {
  return date.toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}

export function CustomerDetail({ customerId, customers, onClose, onUpdateCustomer, onViewOrder }: CustomerDetailProps) {
  const customer = customers.find(c => c.id === customerId);
  const [isEditingNotes, setIsEditingNotes] = useState(false);
  const [notes, setNotes] = useState(customer?.notes || '');

  if (!customer) {
    return (
      <div className="bg-white min-h-screen max-w-md mx-auto flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-gray-900 mb-2">Клиент не найден</h2>
          <Button onClick={onClose} variant="outline">
            Вернуться к списку
          </Button>
        </div>
      </div>
    );
  }

  const statusConfig = {
    active: { label: 'Активный', color: 'border-green-500 text-green-500' },
    vip: { label: 'VIP', color: 'border-gray-600 text-gray-600' },
    inactive: { label: 'Неактивный', color: 'border-gray-400 text-gray-400' }
  };

  const orderStatusConfig = {
    pending: { label: 'Ожидает', color: 'bg-yellow-100 text-yellow-700' },
    confirmed: { label: 'Подтвержден', color: 'bg-blue-100 text-blue-700' },
    in_progress: { label: 'В работе', color: 'bg-orange-100 text-orange-700' },
    ready: { label: 'Готов', color: 'bg-green-100 text-green-700' },
    delivered: { label: 'Доставлен', color: 'bg-gray-100 text-gray-700' },
    cancelled: { label: 'Отменен', color: 'bg-red-100 text-red-700' }
  };

  // Фильтруем заказы этого клиента (в реальном приложении это будет API запрос)
  const getCustomerOrders = (customerId: number) => {
    const orderRanges = {
      1: [1, 5],  // Анна Кожемякина - 5 заказов
      2: [6, 8],  // Второй клиент - 3 заказа 
      3: [9, 10], // Третий клиент - 2 заказа
      4: [11, 12], // Четвертый клиент - 2 заказа
      5: [13, 14]  // Пятый клиент - 2 заказа
    };
    
    const range = orderRanges[customerId as keyof typeof orderRanges];
    if (!range) return [];
    
    return mockOrders.filter(order => {
      const orderId = parseInt(order.id);
      return orderId >= range[0] && orderId <= range[1];
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const customerOrders = getCustomerOrders(customerId);

  const handleSaveNotes = () => {
    const updatedCustomer = { ...customer, notes };
    onUpdateCustomer(updatedCustomer);
    setIsEditingNotes(false);
  };

  const handleCancelNotes = () => {
    setNotes(customer.notes || '');
    setIsEditingNotes(false);
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Mobile Header */}
      <div className="flex items-center p-4 border-b border-gray-100 lg:hidden">
        <Button 
          variant="ghost" 
          size="sm" 
          className="p-2 mr-3"
          onClick={onClose}
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </Button>
        <h1 className="text-gray-900">Клиент</h1>
      </div>

      {/* Desktop Header */}
      <div className="hidden lg:block border-b border-gray-200 p-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={onClose} className="p-2">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">
              {customer.name && customer.name.trim() ? customer.name : `Клиент ${customer.phone.slice(-4)}`}
            </h1>
            <p className="text-gray-600 mt-1">Карточка клиента и история заказов</p>
          </div>
        </div>
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:block p-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Left Column - Customer Info & Stats */}
            <div className="xl:col-span-1 space-y-6">
              {/* Customer Info Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5" />
                    Информация о клиенте
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <h3 className={`text-lg font-medium truncate ${
                        customer.name && customer.name.trim() ? 'text-gray-900' : 'text-gray-600 italic'
                      }`}>
                        {customer.name && customer.name.trim() ? customer.name : `Клиент ${customer.phone.slice(-4)}`}
                      </h3>
                    </div>
                    <Badge variant="secondary" className={`flex-shrink-0 ${
                      customer.status === 'vip' ? 'bg-purple-100 text-purple-700' :
                      customer.status === 'active' ? 'bg-green-100 text-green-700' :
                      'bg-gray-100 text-gray-600'
                    }`}>
                      {statusConfig[customer.status].label}
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center text-gray-600">
                      <Phone className="w-4 h-4 mr-3" />
                      <span>{customer.phone}</span>
                    </div>
                    
                    <div className="flex items-center text-gray-600">
                      <Calendar className="w-4 h-4 mr-3" />
                      <span>Клиент с {formatDate(customer.memberSince)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Stats Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Статистика
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <ShoppingBag className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Заказов</div>
                          <div className="font-semibold text-gray-900">{customer.totalOrders}</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                          <Receipt className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Потрачено</div>
                          <div className="font-semibold text-gray-900">{formatCurrency(customer.totalSpent)}</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                          <TrendingUp className="w-5 h-5 text-purple-600" />
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Средний чек</div>
                          <div className="font-semibold text-gray-900">
                            {Math.round(customer.totalSpent / customer.totalOrders)}₸
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Notes Card */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Заметки</CardTitle>
                    {!isEditingNotes && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="p-2"
                        onClick={() => setIsEditingNotes(true)}
                      >
                        <Edit3 className="w-4 h-4 text-gray-500" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {isEditingNotes ? (
                    <div className="space-y-3">
                      <Textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Добавьте заметку о клиенте..."
                        className="min-h-[100px] resize-none"
                        autoFocus
                      />
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          onClick={handleSaveNotes}
                          className="flex-1"
                        >
                          Сохранить
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          onClick={handleCancelNotes}
                          className="flex-1"
                        >
                          Отмена
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-gray-600 min-h-[60px] flex items-center">
                      {customer.notes || (
                        <span className="text-gray-400 italic">Нажмите для добавления заметки...</span>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Order History */}
            <div className="xl:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    История заказов
                    <Badge variant="secondary" className="ml-2">
                      {customerOrders.length}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {customerOrders.length > 0 ? (
                    <div className="border rounded-lg">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Номер заказа</TableHead>
                            <TableHead className="w-32">Дата</TableHead>
                            <TableHead>Товары</TableHead>
                            <TableHead className="w-32">Сумма</TableHead>
                            <TableHead className="w-32">Статус</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {customerOrders.map((order) => (
                            <TableRow 
                              key={order.id}
                              className="cursor-pointer hover:bg-gray-50"
                              onClick={() => onViewOrder?.(order.id)}
                            >
                              <TableCell>
                                <div className="font-medium">#{order.number}</div>
                              </TableCell>
                              <TableCell>
                                <div className="text-sm text-gray-600">
                                  {formatOrderDate(order.date)}
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="text-sm">
                                  {order.items.length === 1 ? (
                                    order.items[0].name
                                  ) : (
                                    `${order.items[0].name}${order.items.length > 1 ? ` +${order.items.length - 1}` : ''}`
                                  )}
                                </div>
                                {order.items.length > 1 && (
                                  <div className="text-xs text-gray-400">
                                    {order.items.length} позиций в заказе
                                  </div>
                                )}
                              </TableCell>
                              <TableCell>
                                <div className="font-medium">{formatCurrency(order.total)}</div>
                              </TableCell>
                              <TableCell>
                                <Badge 
                                  variant="secondary" 
                                  className={`text-xs ${orderStatusConfig[order.status].color}`}
                                >
                                  {orderStatusConfig[order.status].label}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <TrendingUp className="w-8 h-8 text-gray-400" />
                      </div>
                      <h4 className="text-lg font-medium text-gray-900 mb-2">Нет заказов</h4>
                      <p className="text-gray-500">Заказы этого клиента появятся здесь</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="lg:hidden pb-6">
        {/* Customer Info */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <h2 className={`truncate ${customer.name && customer.name.trim() ? 'text-gray-900' : 'text-gray-600 italic'}`}>
                {customer.name && customer.name.trim() ? customer.name : `Клиент ${customer.phone.slice(-4)}`}
              </h2>
            </div>
            <div className="px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-600 flex-shrink-0">
              {statusConfig[customer.status].label}
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center text-gray-600">
              <Phone className="w-4 h-4 mr-3" />
              <span>{customer.phone}</span>
            </div>
            
            <div className="flex items-center text-gray-600">
              <Calendar className="w-4 h-4 mr-3" />
              <span>Клиент с {formatDate(customer.memberSince)}</span>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="p-4 border-b border-gray-100">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-gray-900">{customer.totalOrders}</div>
              <div className="text-sm text-gray-500">
                {customer.totalOrders === 1 ? 'заказ' : customer.totalOrders < 5 ? 'заказа' : 'заказов'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-gray-900">{formatCurrency(customer.totalSpent)}</div>
              <div className="text-sm text-gray-500">потрачен��</div>
            </div>
            <div className="text-center">
              <div className="text-gray-900">
                {Math.round(customer.totalSpent / customer.totalOrders)}₸
              </div>
              <div className="text-sm text-gray-500">средний чек</div>
            </div>
          </div>
        </div>

        {/* Notes */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-gray-900">Заметки</h3>
            {!isEditingNotes && (
              <Button 
                variant="ghost" 
                size="sm" 
                className="p-1"
                onClick={() => setIsEditingNotes(true)}
              >
                <Edit3 className="w-4 h-4 text-gray-500" />
              </Button>
            )}
          </div>

          {isEditingNotes ? (
            <div className="space-y-3">
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Добавьте заметку о клиенте..."
                className="min-h-[80px] resize-none"
                autoFocus
              />
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  onClick={handleSaveNotes}
                  className="bg-gray-800 hover:bg-gray-900"
                >
                  Сохранить
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={handleCancelNotes}
                >
                  Отмена
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-gray-600">
              {customer.notes || (
                <span className="text-gray-400 italic">Нажмите для добавления заметки...</span>
              )}
            </div>
          )}
        </div>

        {/* Order History */}
        <div className="p-4">
          <div className="mb-3">
            <h3 className="text-gray-900">История заказов</h3>
          </div>

          {customerOrders.length > 0 ? (
            <div className="space-y-3">
              {customerOrders.map((order) => (
                <div 
                  key={order.id}
                  className="p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => onViewOrder?.(order.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-gray-900">#{order.number}</span>
                      <div className={`px-2 py-0.5 rounded text-xs ${orderStatusConfig[order.status].color}`}>
                        {orderStatusConfig[order.status].label}
                      </div>
                    </div>
                    <span className="text-gray-900">{formatCurrency(order.total)}</span>
                  </div>
                  
                  <div className="text-sm text-gray-600 mb-1">
                    {formatOrderDate(order.date)}
                  </div>
                  
                  <div className="text-sm text-gray-500">
                    {order.items.length === 1 ? (
                      order.items[0].name
                    ) : (
                      `${order.items[0].name}${order.items.length > 1 ? ` +${order.items.length - 1}` : ''}`
                    )}
                  </div>
                  
                  {order.items.length > 1 && (
                    <div className="text-xs text-gray-400 mt-1">
                      {order.items.length} позиций в заказе
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <TrendingUp className="w-6 h-6 text-gray-400" />
              </div>
              <h4 className="text-gray-900 mb-1">Нет заказов</h4>
              <p className="text-sm text-gray-500">Заказы этого клиента появятся здесь</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}