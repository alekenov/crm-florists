// This file has been moved to /components/orders/OrderDetail.tsx
// Keeping this file for backward compatibility
export { OrderDetail } from './orders/OrderDetail';